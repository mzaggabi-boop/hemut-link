export { default } from "./stars";
