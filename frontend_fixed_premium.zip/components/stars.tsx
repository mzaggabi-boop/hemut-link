export default function Stars({
  value,
  size = 16,
}: {
  value: number;
  size?: number;
}) {
  const stars = [1, 2, 3, 4, 5];

  return (
    <span className="flex gap-0.5">
      {stars.map((s) => (
        <svg
          key={s}
          width={size}
          height={size}
          viewBox="0 0 24 24"
          className="drop-shadow-sm"
          fill={s <= value ? "#facc15" : "#e5e7eb"}
        >
          <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.62L12 2 9.19 8.62 2 9.24l5.46 4.73L5.82 21z" />
        </svg>
      ))}
    </span>
  );
}