export { default } from "../app/components/Maproute";
